This program contains contains Java based Airline Flight Management System.
Using following technologies in this program:
  1. Java
  2. Java Swing
  3. Java Web
  4. Junit Testing
  5. File System as database
